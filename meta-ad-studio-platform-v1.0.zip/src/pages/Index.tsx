import { Layout } from '@/components/Layout';

const Index = () => {
  return <Layout />;
};

export default Index;
