export interface GeneratedImage {
  id: string;
  url: string;
  prompt: string;
  timestamp: Date;
  engagement?: number;
  ctr?: number;
  reach?: number;
}

export interface TrendingConcept {
  id: string;
  title: string;
  description: string;
  growth: string;
  engagement: string;
  platforms: string[];
  trend: 'up' | 'down' | 'stable';
  promptSuggestion: string;
}

export interface PredictiveInsight {
  id: string;
  metric: string;
  predicted: string;
  confidence: string;
  change: 'up' | 'down' | 'stable';
}

export const mockImages: GeneratedImage[] = [
  {
    id: '1',
    url: 'https://images.unsplash.com/photo-1518709268805-4e9042af2176?w=800&h=600&fit=crop',
    prompt: 'Luxury fashion brand launching in VR showroom with holographic models',
    timestamp: new Date(),
    engagement: 87,
    ctr: 4.2,
    reach: 125000
  },
  {
    id: '2', 
    url: 'https://images.unsplash.com/photo-1551739440-5dd934d3a94a?w=800&h=600&fit=crop',
    prompt: 'Gaming platform community event with neon aesthetics',
    timestamp: new Date(),
    engagement: 92,
    ctr: 5.8,
    reach: 98000
  },
  {
    id: '3',
    url: 'https://images.unsplash.com/photo-1620121692029-d088224ddc74?w=800&h=600&fit=crop', 
    prompt: 'NFT art collection reveal in cyberpunk metaverse environment',
    timestamp: new Date(),
    engagement: 79,
    ctr: 3.9,
    reach: 156000
  },
  {
    id: '4',
    url: 'https://images.unsplash.com/photo-1634017839464-5c339ebe3cb4?w=800&h=600&fit=crop',
    prompt: 'Sustainable tech product launch in virtual eco-space',
    timestamp: new Date(),
    engagement: 84,
    ctr: 4.7,
    reach: 112000
  }
];

export const trendingConcepts: TrendingConcept[] = [
  {
    id: '1',
    title: 'Solarpunk Aesthetics',
    description: 'Bio-architecture and green/gold palettes dominating Decentraland',
    growth: '+342%',
    engagement: '94.2%',
    platforms: ['Decentraland', 'VRChat', 'Horizon'],
    trend: 'up',
    promptSuggestion: 'Incorporate bio-architecture elements with green and gold color palette in sustainable tech showcase'
  },
  {
    id: '2', 
    title: 'Interactive Holographic Concerts',
    description: 'User avatars influencing live music performances',
    growth: '+198%',
    engagement: '87.8%',
    platforms: ['VRChat', 'Rec Room', 'Meta Horizon'],
    trend: 'up',
    promptSuggestion: 'Create immersive concert experience where audience avatars can interact with holographic performers'
  },
  {
    id: '3',
    title: 'Minimalist Luxury Spaces',
    description: 'Clean, premium environments with subtle brand integration',
    growth: '+156%',
    engagement: '91.5%', 
    platforms: ['Spatial', 'Mozilla Hubs', 'NVIDIA Omniverse'],
    trend: 'up',
    promptSuggestion: 'Design elegant minimalist showroom with subtle luxury brand elements and premium materials'
  },
  {
    id: '4',
    title: 'Gamified Shopping',
    description: 'Quest-based product discovery in virtual marketplaces',
    growth: '+278%',
    engagement: '88.9%',
    platforms: ['Roblox', 'Fortnite Creative', 'Core'],
    trend: 'up',
    promptSuggestion: 'Transform product showcase into interactive adventure where users unlock features through exploration'
  }
];

export const basePredictiveInsights: PredictiveInsight[] = [
  {
    id: '1',
    metric: 'Engagement Rate',
    predicted: '89.2%',
    confidence: '94%',
    change: 'up'
  },
  {
    id: '2',
    metric: 'Click-Through Rate', 
    predicted: '4.7%',
    confidence: '87%',
    change: 'up'
  },
  {
    id: '3',
    metric: 'Conversion Rate',
    predicted: '12.3%',
    confidence: '91%',
    change: 'up'
  },
  {
    id: '4',
    metric: 'Reach Multiplier',
    predicted: '2.4x',
    confidence: '89%',
    change: 'up'
  }
];

export const generateRandomInsights = (): PredictiveInsight[] => {
  return basePredictiveInsights.map(insight => ({
    ...insight,
    predicted: generateRandomMetric(insight.metric),
    confidence: `${Math.floor(Math.random() * 15 + 80)}%`,
    change: Math.random() > 0.7 ? 'down' : 'up'
  }));
};

const generateRandomMetric = (metric: string): string => {
  switch (metric) {
    case 'Engagement Rate':
      return `${(Math.random() * 20 + 75).toFixed(1)}%`;
    case 'Click-Through Rate':
      return `${(Math.random() * 3 + 3).toFixed(1)}%`;
    case 'Conversion Rate':
      return `${(Math.random() * 8 + 8).toFixed(1)}%`;
    case 'Reach Multiplier':
      return `${(Math.random() * 2 + 2).toFixed(1)}x`;
    default:
      return '0%';
  }
};

export const promptSuggestions = {
  assisted: [
    'Luxury fashion brand launching in VR showroom',
    'Gaming platform community event announcement', 
    'NFT art collection reveal campaign'
  ],
  categories: [
    'Visual Ads',
    'Interactive Experiences', 
    'Brand Activations',
    'Product Showcases'
  ]
};