import { create } from 'zustand';
import { GeneratedImage, PredictiveInsight } from '@/lib/mockData';

export type UserRole = 'Director' | 'Copywriter' | 'Client';
export type CanvasState = 'welcome' | 'generating' | 'results';

interface AppState {
  // Prompt and generation
  promptText: string;
  setPromptText: (text: string) => void;
  
  // Generated assets
  generatedAssets: GeneratedImage[];
  setGeneratedAssets: (assets: GeneratedImage[]) => void;
  
  // Canvas state
  canvasState: CanvasState;
  setCanvasState: (state: CanvasState) => void;
  
  // User role
  currentUserRole: UserRole;
  setCurrentUserRole: (role: UserRole) => void;
  
  // Analytics
  predictiveInsights: PredictiveInsight[];
  setPredictiveInsights: (insights: PredictiveInsight[]) => void;
  
  // Loading states
  isGeneratingStrategy: boolean;
  setIsGeneratingStrategy: (loading: boolean) => void;

  // Prompt UI shake trigger (for empty prompt feedback)
  promptShake: number;
  setPromptShake: (val: number) => void;
  
  // Selected image for modal
  selectedImage: GeneratedImage | null;
  setSelectedImage: (image: GeneratedImage | null) => void;
}

export const useStore = create<AppState>((set) => ({
  // Prompt and generation
  promptText: '',
  setPromptText: (text) => set({ promptText: text }),
  
  // Generated assets
  generatedAssets: [],
  setGeneratedAssets: (assets) => set({ generatedAssets: assets }),
  
  // Canvas state
  canvasState: 'welcome',
  setCanvasState: (state) => set({ canvasState: state }),
  
  // User role
  currentUserRole: 'Director',
  setCurrentUserRole: (role) => set({ currentUserRole: role }),
  
  // Analytics
  predictiveInsights: [],
  setPredictiveInsights: (insights) => set({ predictiveInsights: insights }),
  
  // Loading states
  isGeneratingStrategy: false,
  setIsGeneratingStrategy: (loading) => set({ isGeneratingStrategy: loading }),

  // Prompt shake
  promptShake: 0,
  setPromptShake: (val) => set({ promptShake: val }),
  
  // Selected image for modal
  selectedImage: null,
  setSelectedImage: (image) => set({ selectedImage: image }),
}));

// Expose store to window for E2E tests to inspect state (only in browser)
// Provide a safe getter so consumers (and tests) can access the hook factory
export function getAppStore() {
  return useStore;
}

// Attach to window when running in the browser. Prefer attaching from the
// application entry (`main.tsx`) for reliability in production/preview builds.
declare global {
  interface Window {
    __APP_STORE__?: unknown;
  }
}

if (typeof window !== 'undefined' && import.meta.env.VITE_APP_ENV === 'development' && !window.__APP_STORE__) {
  window.__APP_STORE__ = useStore;
}