import { createRoot } from "react-dom/client";
import App from "./App.tsx";
import "./index.css";
import { getAppStore } from '@/store/useStore';
// Sentry: initialize only in production
if (typeof window !== 'undefined' && import.meta.env.PROD && import.meta.env.VITE_SENTRY_DSN) {
	// Dynamic import keeps dev bundles small and satisfies lint rules.
	void (async () => {
		const Sentry = await import('@sentry/react');
		const tracing = await import('@sentry/tracing');
		Sentry.init({
			dsn: import.meta.env.VITE_SENTRY_DSN,
			integrations: [new tracing.BrowserTracing()],
			tracesSampleRate: 0.1,
		});
	})();
}

// Typed attachment of the dev-only store hook factory for E2E tests.
declare global {
	interface Window {
		__APP_STORE__?: unknown;
	}
}

// Attach dev-only store to window only in development environment for E2E.
if (typeof window !== 'undefined' && import.meta.env.VITE_APP_ENV === 'development' && !window.__APP_STORE__) {
	window.__APP_STORE__ = getAppStore();
	console.info('E2E: __APP_STORE__ attached (development only)');
}

createRoot(document.getElementById("root")!).render(<App />);
