import { CampaignCanvas } from '@/components/CampaignCanvas';

export default function CampaignsPage() {
  return <CampaignCanvas />;
}